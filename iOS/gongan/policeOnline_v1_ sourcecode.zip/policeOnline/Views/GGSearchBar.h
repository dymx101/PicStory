//
//  GGSearchBar.h
//  tmd
//
//  Created by dong yiming on 13-4-10.
//  Copyright (c) 2013年 tmd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GGSearchBar : UISearchBar
-(UIButton *)cancelButton;
@end
