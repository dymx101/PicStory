//
//  GGVersionInfo.h
//  policeOnline
//
//  Created by dong yiming on 13-4-29.
//  Copyright (c) 2013年 tmd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GGDataModel.h"

@interface GGVersionInfo : GGDataModel
@property (copy) NSString *verName;
@property (copy) NSString *verCode;
@property (copy) NSString *updates;
@end
