//
//  GGMainVC.h
//  policeOnline
//
//  Created by dong yiming on 13-4-28.
//  Copyright (c) 2013年 tmd. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "GGGps.h"
#import "BMapKit.h"

@interface GGMainVC : GGBaseViewController <BMKMapViewDelegate>

@end
