//
//  GGDefine.m
//  WeiGongAn
//
//  Created by dong yiming on 13-4-1.
//  Copyright (c) 2013年 WeiGongAn. All rights reserved.
//

#import "GGDefine.h"

@implementation GGDefine

@end
