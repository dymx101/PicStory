//
//  GGViewController.h
//  policeOnline
//
//  Created by dong yiming on 13-4-27.
//  Copyright (c) 2013年 tmd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GGTestVC : GGBaseViewController

@end
