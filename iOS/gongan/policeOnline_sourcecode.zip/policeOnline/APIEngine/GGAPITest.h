//
//  GGAPITest.h
//  WeiGongAn
//
//  Created by dong yiming on 13-4-8.
//  Copyright (c) 2013年 WeiGongAn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GGAPITest : NSObject
AS_SINGLETON(GGAPITest)

-(void)run;
@end
