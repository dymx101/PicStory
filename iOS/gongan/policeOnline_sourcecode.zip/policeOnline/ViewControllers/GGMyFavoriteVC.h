//
//  GGMyFavoriteVC.h
//  policeOnline
//
//  Created by towne on 13-4-29.
//  Copyright (c) 2013年 tmd. All rights reserved.
//

#import "GGBaseViewController.h"

@interface GGMyFavoriteVC : GGBaseViewController<UITableViewDelegate,UITableViewDataSource>
@property (copy) NSString *naviTitleString;
@end
