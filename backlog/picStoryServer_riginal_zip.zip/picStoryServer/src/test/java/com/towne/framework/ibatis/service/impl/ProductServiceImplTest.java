package com.towne.framework.ibatis.service.impl;


//@ContextConfiguration(locations="classpath:spring-ibatis.xml")
//@RunWith(value=SpringJUnit4ClassRunner.class)
public class ProductServiceImplTest {
	
	/*@Resource(name="productServiceImpl")
	private ProductService productService;
	
	@Test
	public void listAll(){
		List<Product> lists=productService.listAll();
		for (Product product : lists) {
			System.out.println(product.getName()+"\t"+product.getDescription()+"\t"+product.getCategory().getId()+"\t"+product.getCategory().getName());
		}
	}
	
	@Test
	public void save(){
		Product product=new Product();
		product.setName("ipad2");
		product.setPrice(3000.f);
		product.setDescription("ipad2");
		product.setCategoryid("1");
		boolean b=productService.save(product);
		System.out.println(b);
		
	}
	
	
	@Test
	public void update(){
		Product product=productService.getModel(3);
		product.setName("mac pro");
		product.setDescription("苹果笔记本");
		boolean b=productService.update(product);
		System.out.println(b);
		
	}
	
	
	@Test
	public void selectLikeName(){
		List<Product> lists=productService.selectLikeName("o");
		for (Product product : lists) {
			System.out.println(product.getName()+"\t"+product.getDescription()+"\t"+product.getCategory().getId()+"\t"+product.getCategory().getName());
		}
	}*/
}
