package com.towne.framework.spring.jdbc.service;

import com.towne.framework.common.service.IService;
import com.towne.framework.spring.jdbc.model.Category;

public interface CategoryService extends IService<Category> {

}
