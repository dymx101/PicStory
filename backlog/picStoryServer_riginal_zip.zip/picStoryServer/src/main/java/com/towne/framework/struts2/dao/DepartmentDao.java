package com.towne.framework.struts2.dao;

import com.towne.framework.common.dao.IDao;
import com.towne.framework.struts2.model.Department;

public interface DepartmentDao extends IDao<Department>{
	
}
