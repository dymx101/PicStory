package com.towne.framework.mybatis.dao;

public interface CategoryMapper {

}
