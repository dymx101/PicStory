package com.towne.framework.struts2.service;

import com.towne.framework.common.service.IService;
import com.towne.framework.struts2.model.Department;

public interface DepartmentService extends IService<Department>{

}
