package com.towne.framework.spring.jdbc.dao;

import com.towne.framework.common.dao.IDao;
import com.towne.framework.spring.jdbc.model.Category;

public interface CategoryDao extends IDao<Category> {

}
